public class Modulate {
	public static void main(String[] args) {
		int mod = -5%2;
		System.out.println(mod);
	}
}
