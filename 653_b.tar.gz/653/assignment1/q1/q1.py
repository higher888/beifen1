x = -5%2
print x

