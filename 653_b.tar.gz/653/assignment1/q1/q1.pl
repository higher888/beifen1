#!/usr/bin/perl

$x = -5;
$mod = $x % 2;
print "the perl version of mod is $mod\n";

