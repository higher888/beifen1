#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/wait.h>
int pid_K=0;
int pid_R=0;
int pid_1=0;
int pid_2=0;
int main (int argc, char *argv[])
{
	int pipeR_1[2];
	int pipeK1_2[2];
	int pid,pid1,pid2;
	char buf[100];
	pipe(pipeR_1);
	pipe(pipeK1_2);
	pid = fork();
	if (pid>0)
	{	
			pid_R=getpid();
			close(pipeR_1[0]);
			dup2(pipeR_1[1],STDOUT_FILENO); //
			execv("rgen", argv);
	}
	else
	{
		pid1= fork();
		if (pid1>0)
		{

		pid_K=getpid();
		while(fgets(buf,100, stdin)!=NULL)
		{
		write(pipeK1_2[1],buf,strlen(buf));
		}
		kill(pid_R,SIGKILL);
		kill(pid_1,SIGKILL);
		kill(pid_2,SIGKILL);
		}
		else
		{
			pid2 = fork();
			if (pid2>0)
			{
				pid_1=getpid();
				close(pipeR_1[1]);
				close(pipeK1_2[0]);
				dup2(pipeR_1[0],STDIN_FILENO);
				dup2(pipeK1_2[1],STDOUT_FILENO);
				execl("/usr/bin/python", "/usr/bin/python", "./a1-ece650.py", (char *)NULL);
			}	
			else
			{
				pid_2=getpid();
			        close(pipeK1_2[1]);
				dup2(pipeK1_2[0],STDIN_FILENO);
				execlp("./a2-ece650","a2-ece650",NULL);
			}
		}
	}
}




