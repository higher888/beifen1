import sys
import re




def intersection(x1,y1,x2,y2,x3,y3,x4,y4):
	d = (y2-y1)*(x4-x3)-(y4-y3)*(x2-x1)
	if d == 0:
		return
	else:
		x0 = ((x2-x1)*(x4-x3)*(y3-y1)+(y2-y1)*(x4-x3)*x1-(y4-y3)*(x2-x1)*x3)/d
		y0 = ((y2-y1)*(y4-y3)*(x3-x1)+(x2-x1)*(y4-y3)*y1-(x4-x3)*(y2-y1)*y3)/(-d)
	#determine whether the intersection is on the edges
	inter_list = []
	if (x0-x1)*(x0-x2)<=0 and  (x0-x3)*(x0-x4)<=0 and  (y0-y1)*(y0-y2)<=0 and  (y0-y3)*(y0-y4)<=0:
		inter_list.append(x0)
		inter_list.append(y0)
		return  inter_list
	else: 
		return 0

###MAIN OPERATIONS
evaluation = 0;
streetData_1_dic = {}

while evaluation == 0:
#	print 'please insert your command: '
	newCommand = sys.stdin.readline() #ask for user command
		

	a1 = re.match(r'^\s*a',newCommand)
	c1 = re.match(r'^\s*c',newCommand)
	r1 = re.match(r'^\s*r',newCommand)
	g1 = re.match(r'^\s*g',newCommand)

 

###FUNCTIONS
	##The following step is to determine and check the type of command
	if a1:    #ADD command
		check_a = re.match(r'\s*(a)\s*(\".+\")\s*(\s*\(\s*-?\d+\s*,\s*-?\d+\s*\)){2,10}\s*$',newCommand)
		newData = []	
		check_a1 = re.match(r'\s*(a)\s*(\".+\")\s*(\s*\(\s*-?\d+\s*,\s*-?\d+\s*\))\s*$',newCommand)
		x = re.match(r'(\s*a\s*)(\".*\")(.*)$',newCommand)	
			
		if check_a:
			newData.append(check_a.group())

			streetName = re.search(r'(\".+\")',newCommand)
			coordinate = re.compile(r'(-?\d+)')

                        i = 0
                        
			for newStreet in coordinate.finditer(x.group(3)):
				newData.append(newStreet.group())  #all the number is obtained
				i=i+1
			
			streetData_1 = []
			streetData_1.append(streetName.group())

			

                 	if streetData_1[0] in streetData_1_dic:       
				sys.stderr.write("Error: 'a' specified for a street that already exists!\n")
			
			
			else:	
				for j in range(1,i+1):
					streetData_1.append(float(newData[j]))
			
			
#				print streetData_1
                        
				streetData_1_dic[streetData_1[0]]=streetData_1[1:]#the added street information is stored in the dictionary
#				print streetData_1_dic
		elif check_a1:
			streetName = re.search(r'(\".+\")',newCommand)	
			streetData_2 = []
			streetData_2.append(streetName.group())
			

			sys.stderr.write("Error: Incomplete coordinates in a %s, no end points!\n"% streetData_2[0])

			       
		else:
			sys.stderr.write("Error: Your command has syntax errors!\n")
			continue
	
		          
	elif c1: #CHANGE command
		check_c = re.match(r'\s*(c)\s*(\".+\")\s*(\s*\(\s*-?\d+\s*,\s*-?\d+\s*\)){2,10}\s*$',newCommand)
		check_c1 = re.match(r'\s*(c)\s*(\".+\")\s*(\s*\(\s*-?\d+,\s*-?\d+\s*\))\s*$',newCommand)
	
		
		if check_c:
			newData = []
#			newData.append(check_c.group())
			streetName = re.search(r'(\".+\")',newCommand)
			coordinate = re.compile(r'(-?\d+)')
#			print "right"
		 	i = 0
			
			for newStreet in coordinate.finditer(newCommand):
				newData.append(newStreet.group())  #all the number is obtained
				i=i+1
				
			streetData_2 = []
			streetData_1 = []
			streetData_2.append(streetName.group())
			
			if streetData_2[0] in streetData_1_dic:					
				for j in range(0,i):
					streetData_1.append(float(newData[j]))
			
			
#				print streetData_1
                        
				streetData_1_dic[streetData_2[0]]=streetData_1[0:]#the added street information is stored in the dictionary
	#			print streetData_1_dic
			else:
				sys.stderr.write("Error: 'c' specified for a street that does not exist!\n")
	
		elif check_c1:	
			streetName = re.search(r'(\".+\")',newCommand)	
			streetData_2 = []
			streetData_2.append(streetName.group())
			
			sys.stderr.write("Error: Incomplete coordinates in a %s, no end points!\n"% streetData_2[0])

		       
		else:
			sys.stderr.write("Error: Your command has syntax errors!\n")
			continue

	elif r1:             #remove a street
		check_r = re.match(r'\s*(r)\s*(\".+\")\s*$',newCommand)
		
		
			
		if check_r:
			newData = []
	 		newData.append(check_r.group())
			streetName = re.search(r'(\".+\")',newCommand)
#			print "right"
		 			
			streetData_1 = []
			streetData_1.append(streetName.group())

			
#			print streetData_1
                 	if streetData_1[0] in streetData_1_dic:       
				del streetData_1_dic[streetData_1[0]] #delete corresponding street
#			print streetData_1_dic
			
			else:
				sys.stderr.write("Error: 'r' specified for a street that does not exist!\n")
			       
		else:
			sys.stderr.write("Error:Your command has syntax errors!\n")
			continue

	elif g1:  #OUTPUT command
	
		check_g = re.match(r'\s*(g)\s*$',newCommand)
						
			
		if check_g:
		
			street_name = []
			street_length = []
			street_num = 0
			street_inter_sum = []
			streetData_2_dic = {}
			inter_return_flag = 0


			for (k,v) in streetData_1_dic.items():
				street_name.append(k)
				street_length.append(len(v))
				street_num = street_num + 1
				streetData_2_dic[k]=v
			#print street_name
			#print street_length
			#print street_num



			for loop in range(0,street_num-1):
				for loop1 in range(loop + 1,street_num):
					street1 = streetData_1_dic[street_name[loop]]
       					street2 = streetData_1_dic[street_name[loop1]]
					street1_length = street_length[loop]
					street2_length = street_length[loop1]
#					print loop
#					print loop1
#					print street1
#					print street2
#					print street1_length
#					print street2_length

	
					for length1 in range(street1_length/2-1):
						for length2 in range(street2_length/2-1):
							x1 = street1[length1*2]
							y1 = street1[length1*2+1]
							x2 = street1[length1*2+2]
							y2 = street1[length1*2+3]
  
							x3 = street2[length2*2]
							y3 = street2[length2*2+1]
							x4 = street2[length2*2+2]
							y4 = street2[length2*2+3]
				
				
#							print [x1,y1,x2,y2,x3,y3,x4,y4]
							inter_return = intersection(x1,y1,x2,y2,x3,y3,x4,y4) 
		                			if inter_return:
								street_inter_sum.append(inter_return[0])
								street_inter_sum.append(inter_return[1]) 
								inter_return_flag = inter_return_flag + 1
#							print street_inter_sum

#							print length1
#							print length2

#							print inter_return
#							print type(inter_return)				
#if there is intersection, the dictionary of one or two street are updated			
							if inter_return and (inter_return[0]!=x1 or inter_return[1]!=y1) and (inter_return[0]!=x2 or inter_return[1]!=y2):
								a1 = []
								a2 = []
								a3 = []
								street1_1 = streetData_2_dic[street_name[loop]]
       								n = 0
								while street1_1[n*2] != x1 or street1_1[n*2+1]!=y1:
									n = n+1 
			
								a1.append(streetData_2_dic[street_name[loop]][:n*2+2])
								a2.append(inter_return[0])
								a2.append(inter_return[1])
								a3.append(streetData_2_dic[street_name[loop]][n*2+2:])
								a = a1[0] + a2 + a3[0]
								streetData_2_dic[street_name[loop]]=a
									
										
				

				
					

								
							if inter_return and (inter_return[0]!=x3 or inter_return[1]!=y3) and (inter_return[0]!=x4 or inter_return[1]!=y4):
								b1 = []
								b2 = []
								b3 = []	
								street2_1 = streetData_2_dic[street_name[loop1]]

								m = 0
								while street2_1[m*2] != x3 or street2_1[m*2+1]!=y3:
									m = m+1  
								b1.append(streetData_2_dic[street_name[loop1]][:m*2+2])
								b2.append(inter_return[0])
								b2.append(inter_return[1])
								b3.append(streetData_2_dic[street_name[loop1]][m*2+2:])
								b = b1[0] + b2 + b3[0]
								streetData_2_dic[street_name[loop1]]=b
	
#							print streetData_1_dic
#							print streetData_2_dic



				
		
	

#			print streetData_1_dic
#			print streetData_2_dic



#determine an order if there are two same intersection next to each other on the same street
			
			for (k,v) in streetData_2_dic.items():
				street_flag = 0
				street_update = []
				for i1 in range(len(v)/2-1):
					if v[i1*2] == v[i1*2+2] and v[i1*2+1] == v[i1*2+3]:
						street_update.append(v[:i1*2+2])
						street_update.append(v[i1*2+4:])
			
						street_flag = 1
					if street_flag == 1:
						streetData_2_dic[k] = street_update[0] + street_update[1]


 
#                        print streetData_2_dic
			for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0




			for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0



                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0

                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0




			for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0



                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0

# 			print streetData_2_dic

			for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0



                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0

                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0




			for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0



                        for (k,v) in streetData_2_dic.items():
                                for i6 in range(0,5):
                                        for i2 in range(len(v)/2-1):
                                                flag1 = []		
                                                x = 0
                                                flag1.append(x) 
                                                flag1.append(x)	
                                                street_update2 = []
                                                for i3 in range(len(street_inter_sum)/2):
                                                        if v[i2*2] == street_inter_sum[i3*2] and v[i2*2+1] == street_inter_sum[i3*2+1]:
                                                                flag1[0] = 1
                                                                for i4 in range(len(street_inter_sum)/2):
                                                                        if v[i2*2+2] == street_inter_sum[i4*2] and v[i2*2+3] == street_inter_sum[i4*2+1]:
                                                                                flag1[1] = 1
#					print flag1
                                                if flag1[0] == 1 and flag1[1]==1:
                                                        flag2 = 0
                                                        for i11 in range(len(street_inter_sum)/2):
                                                                if v[i2*2-2] == street_inter_sum[i11*2] and v[i2*2-1] == street_inter_sum[i11*2+1]:
                                                                        flag2 = 1
                                                                        
                                                        if (v[i2*2] - v[i2*2-2-flag2*2])**2+(v[i2*2+1]-v[i2*2-1-flag2*2])**2 >  (v[i2*2+2] - v[i2*2-2-flag2*2])**2+(v[i2*2+3]-v[i2*2-1-flag2*2])**2: 
                                                                v1=[]
                                                                v2=[]
                                                                v3=[]
                                                                v4=[]
                                                                v5=[]
				
                                                                v1.append(v[:i2*2])
                                                                v2.append(v[i2*2+2])
                                                                v2.append(v[i2*2+3])	
                                                                v2.append(v[i2*2])
                                                                v2.append(v[i2*2+1])
                                                                v3.append(v[i2*2+4:])
                                                                v0 = v1[0] + v2 + v3[0] 
#							        print v0
                                                                streetData_2_dic[k] = v0

# 			print streetData_2_dic



#PROVIDE THE OUTPUT V AND EDGE E
			if inter_return_flag > 0:
				V = {}
				V_num = 1
				v_flag = 0
#print streetData_1_dic

				E = ()

				for inter_num1 in range(len(street_inter_sum)/2):
					inx = street_inter_sum[inter_num1*2]
					iny = street_inter_sum[inter_num1*2+1]
#					print inx
#					print iny


	
					for (k,v) in streetData_2_dic.items():
						for v_n in range(0,len(v)/2):
#							print v_n
							if v[v_n*2]==inx and v[v_n*2+1]==iny:
								if v_n*2-2>=0 and v_n*2+3<=len(v)-1:
									V[V_num] = (v[v_n*2-2],v[v_n*2-1])
									V[V_num+1] = (v[v_n*2],v[v_n*2+1])
									V[V_num+2] = (v[v_n*2+2],v[v_n*2+3])
									V_num = V_num + 3
							
								elif v_n*2==0 and v_n*2+3<=len(v)-1:
									V[V_num] = (v[v_n*2],v[v_n*2+1])
									V[V_num+1] = (v[v_n*2+2],v[v_n*2+3])
									V_num = V_num + 2

								elif v_n*2-2>=0 and v_n*2+1==len(v)-1:
									V[V_num] = (v[v_n*2-2],v[v_n*2-1])
									V[V_num+1] = (v[v_n*2],v[v_n*2+1])
									V_num = V_num + 2
								elif v_n*2==0 and v_n*2+1==len(v)-1:
									V[V_num+1] = (v[v_n*2],v[v_n*2+1])
									V_num = V_num + 1
#print V

				V_list = []
				for (k,v) in V.items():
					V_list.append(v)
#print V_list
				V_list1 = list(set(V_list))

				V_list2 = sorted(V_list1)
#print V_list2

				V2={}
				V2_num = 1
				V2[V2_num] = V_list2[0]
				V2_num = V2_num + 1
				V2_flag = 0

#print len(V_list)

#####PRINT V

				V_dic = {}
				for i in range(1,len(V_list2)+1):
					V_dic[i] = V_list2[i-1]
#print V_dic 
				write = sys.stdout.write
				'''
				write('V = {\n')
				for i in range(1,len(V_list2)+1):
					write("%d : (%3.2f,%3.2f)\n"% (i,V_dic[i][0],V_dic[i][1]))
				write('}\n')
				'''

				write('V = %d\n'%(len(V_list2)))
				sys.stdout.flush()
		
				streetData_3_dic = {}

######output edge##########
				for (k,v) in streetData_2_dic.items():
					streetData_3_dic[k]=v


				for (k,v) in streetData_3_dic.items():
					list_temp = []
					for j2 in range(len(v)/2):
	
						street_flag = 0;
 						for j1 in range(len(V_list2)):
			
							if V_list2[j1][0] == v[j2*2] and V_list2[j1][1] == v[j2*2+1]:
								list_temp.append(j1+1)
		 						street_flag = 1
						if street_flag == 0:
								list_temp.append(0)
					streetData_3_dic[k] = list_temp
#print streetData_3_dic

				E_list=[]
				for (k,v) in streetData_3_dic.items():
					for j3 in range(len(v)-1):
						if v[j3]!= 0 and v[j3+1]!=0 and v[j3]!=v[j3+1]:
							E_list.append(v[j3])
							E_list.append(v[j3+1])
#print E_list

#Remove the edge that does not connect to intersection
				list_temp2 = []      #record the label of intersection node
				for j7 in range(len(street_inter_sum)/2):
	
					for j6 in range(len(V_list2)):

						if V_list2[j6][0] == street_inter_sum[j7*2] and V_list2[j6][1] == street_inter_sum[j7*2+1]:
	
							list_temp2.append(j6+1)
	
#print list_temp2

							
				write("E = {")
				print_flag = 0
				for j4 in range(len(E_list)/2):
					for j8 in range(len(list_temp2)):
						if E_list[j4*2] == list_temp2[j8] or  E_list[j4*2+1] == list_temp2[j8]:
							if j4 == (len(E_list)/2-1):
								write("<%d,%d>"%((E_list[j4*2]-1),(E_list[j4*2+1]-1)))
							else:
								write("<%d,%d>,"%((E_list[j4*2]-1),(E_list[j4*2+1]-1)))
							break
				write("}\n")
				sys.stdout.flush()
				
			else:
				write = sys.stdout.write
				write('V = {')
				write('}\n')
				write('E = {')
				write('}\n')
#				sys.stdout.flush()


		else:
			sys.stderr.write("Error: Your command has syntax error!\n")
	else:                  #ERROR message
		sys.stderr.write("Error: there is no such command\n") 
		continue	         

