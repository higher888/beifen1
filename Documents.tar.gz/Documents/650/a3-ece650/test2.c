#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
int coincide(int x11,int y11,int x12,int y12,int x13,int y13,int x14,int y14){
	float d,d1,d2,d3,d4;
	float x1 = (float) x11;
	float x2 = (float) x12;
	float x3 = (float) x13;
	float x4 = (float) x14;
	float y1 = (float) y11;
	float y2 = (float) y12;
	float y3 = (float) y13;
	float y4 = (float) y14;

	d = (y2-y1)*(x4-x3)-(y4-y3)*(x2-x1);
	d1 = (y3-y1)*(x2-x3)-(y2-y3)*(x3-x1);
	d2 = (y4-y1)*(x2-x4)-(y2-y4)*(x4-x1);
	d3 = (y1-y3)*(x4-x1)-(y4-y1)*(x1-x3);
	d4 = (y2-y3)*(x4-x2)-(y4-y2)*(x2-x3);

	if(x1==x3 && y1==y3 && x2==x4 && y2==y4){
		return 0;
		}
	else if (d == 0){
		if (d1 == 0 || d2 ==0 || d3 == 0 || d3==0){
			return 0;
		}

	}
	else{
		return 1;	
	}
	
	
	
}

int main(int argc, char* argv[]){

	int x,x1,x2,x3;
	x = coincide(2,3,4,5,2,3,4,5);
	printf("0 %d\n",x);	
	
	x1 = coincide(5,3,4,5,7,3,4,5);
	printf("1 %d\n ",x1);

	x2 = coincide(2,2,4,4,3,3,6,6);
	printf("0 %d\n",x2);	
	
	x1 = coincide(2,7,2,5,2,6,2,3);
	printf("0 %d\n",x3);		


	return 1;
}


