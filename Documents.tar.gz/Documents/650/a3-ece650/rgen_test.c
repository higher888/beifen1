#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>

/*return a random integer between MIN and MAX,inclusive*/
int random_number (int min,int max)
{
	static int dev_random_fd = -1; //file descriptor opened to /dev/urandom
	char* next_random_byte;
	int bytes_to_read;
	unsigned random_value;
	
	/*if this is the first time this function is called, open a file descriptor to /dev/urandom*/

	if (dev_random_fd = -1){
		dev_random_fd = open ("/dev/urandom",O_RDONLY);//open for reading only
//		assert(dev_random_fd) != -1;
	}
	
	/*read enough random bytes to fill an integer variable. */
	next_random_byte = (char*) &random_value;
	bytes_to_read = sizeof (random_value);

	/*loop untile reading enough bytes*/
	do{
		int bytes_read;
		bytes_read = read (dev_random_fd,next_random_byte,bytes_to_read);
		bytes_to_read -= bytes_read;
		next_random_byte += bytes_read;
	} while (bytes_to_read > 0);
	
	/*compute a random number in the correct range.*/
	return min + (random_value % (max - min + 1));
}

/*determine whether new created edge coincide the previous generated*/
int coincide(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4){
	int d;
	double x0,y0;
	d = (y2-y1)*(x4-x3)-(y4-y3)*(x2-x1);
	x0 = ((x2-x1)*(x4-x3)*(y3-y1)+(y2-y1)*(x4-x3)*x1-(y4-y3)*(x2-x1)*x3)/d;
	y0 = ((y2-y1)*(y4-y3)*(x3-x1)+(x2-x1)*(y4-y3)*y1-(x4-x3)*(y2-y1)*y3)/(-d);
	//determine whether the intersection is on the edges
	if ((x0-x1)*(x0-x2)<=0 && (x0-x3)*(x0-x4)<=0 && (y0-y1)*(y0-y2)<=0 && (y0-y3)*(y0-y4)<=0 && d==0)
		return 0;
	else
		return 1;
}

int edgeCheck(int m, int coordinate[m+2],int edge_num,int s_i,int s_j){ 
/*determine if the two nodes are the same*/
	int i,j,c_return,temp;

/*determine if the edge are coincide to the other*/
	for(i=0;i<s_i;i++){
		for(j=0;j<s_j+1;j++){
			temp = i * (edge_num +1) + j;
			c_return = coincide(coordinate[temp],coordinate[temp+1],coordinate[temp+2],coordinate[temp+3],coordinate[m-2],coordinate[m-1],coordinate[m],coordinate[m+1]);
		if(c_return==0){
			return 0;
		}
		}
	}	
	return 1;
}



int main(int argc, char* argv[])
{
	int i,j,m,n,g;
	int sleep_second;
	int k_s,k_n,k_l,k_c;
	int s_flag = 0;
	int n_flag = 0;
	int l_flag = 0;
	int c_flag = 0;
	int edgeError;
	char s1[2];
	char n1[2];
	char l1[2];
	char c1[2];
	int street_num;
	int street_num_p=0;
	int edge_num;

	strcpy(s1,"-s");
	strcpy(n1,"-n");	
	strcpy(l1,"-l");	
	strcpy(c1,"-c");

/******setting the Ks**************/
	for(i = 1;i<argc;i++){ //argc-1 is the number of arguments
//		printf("%c\n",c_temp);
		
		if(strcmp(argv[i],s1)==0){
			k_s = atoi(argv[i+1]);
			s_flag = 1;			
			}
		else if(strcmp(argv[i],n1)==0){
			k_n = atoi(argv[i+1]);
			n_flag = 1;
		}
		else if(strcmp(argv[i],l1)==0){
			k_l = atoi(argv[i+1]);
			l_flag = 1;			
			}
		else if(strcmp(argv[i],c1)==0){
			k_c = atoi(argv[i+1]);
			c_flag = 1;
		}			
	
	}

	if(s_flag==0){
	  k_s = 10;
	}
	if(n_flag==0){
	  k_n = 5;
	}
	if(l_flag==0){
	  k_l = 5;
	}
	if(c_flag==0){
	  k_c = 20;
	}

//	printf("%d %d %d %d\n",k_s,k_n,k_l,k_c);	
/***************generating the streets*********************/
	int xxx=3;
   while(xxx != 2){	
	sleep_second = random_number (5,k_l);//waiting time
	street_num = random_number (2,k_s);
	edge_num = random_number (1,k_n);
		
//	printf("%d %d %d\n",sleep_second,street_num,edge_num);
	int coordinate[2*(edge_num+1)*street_num];
	m = 0;
	for(i=0;i<street_num;++i){		
		for(j=0;j<(edge_num+1);j++){
			for (n = 0; n<25; n++){
				coordinate[m] = random_number (0-k_c,k_c);
				coordinate[m+1] = random_number (0-k_c,k_c);
//				printf("%d %d %d \n",m,coordinate[m],coordinate[m+1]);
/*				if(m>0){
					edgeError = edgeCheck(m,coordinate,edge_num,i,j);
					if (edgeError == 0){
						if (n = 24){
							fprintf(stderr,"Error:failed to generate valid input for 25 simultaneous attempts");
						}
						else
							continue;
					}
				else
						break;
				}*/
				break;
			}


			m = m + 2;			
		}
	}

//	printf("%d %d\n",street_num,edge_num);


	for(i=0;i<street_num_p;++i){
		printf("r \"street %d\"\n",i);		
	}

/*
	m = 0;
	for(i=0;i<street_num;++i){
		printf("a \"street %d\" ",i);
		for(j=0;j<edge_num+1;j++){
			printf("(%d,%d) ",coordinate[m],coordinate[m+1]);
			m = m + 2;
		}
		printf("\n");
	}*/

	printf ("a \"street 0\" (2,-1) (2,2) (5,5) (5,6) (3,8)\n");
	printf ("a \"street 1\" (4,2) (4,8)\n");
	printf ("a \"street 2\" (1,4) (5,8)\n");
	printf("g\n");

	sleep(sleep_second);
	
	street_num_p = 3;
	xxx = xxx -1;
  }

	return 1;

}


