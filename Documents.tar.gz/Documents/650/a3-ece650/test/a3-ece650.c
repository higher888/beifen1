#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <malloc.h>
#include <string.h>

int main(int argc, char* argv[])
{
	int i;
/*	char arg_list[];
	if(argc>1){
		for(i=1;i<argc;i++){
			strcpy(arg_list[i-1], argv[i]);
		}//needs to make sure this is NULL terminated
			arg_list[argc] = NULL;			
	}		
*/
	/*creating the first pipe between rgen and a1-ece650.py*/
	int fds_12[2]; //data written to the file descriptor read [0] can be read back from write [1]

	pid_t pid_rgen;
	pid_t pid_a1; 

	pipe (fds_12);  //create a pipe
	pid_rgen = fork();  //fork a child process for rgen.c
	
	if (pid_rgen == (pid_t) 0) {
// 		close (fds_12[1]);
//		dup2 (fds_12[0],STDOUT_FILENO); //replace the standard output by the read end of the pipe, so that rgen output can be directly sent to read end of pipe
	
		execvp ("./rgen",argv); //replace the child process with the "sort" program, so that the rgen generate the output.
	}
/*	else{
		waitpid (pid_rgen,NULL,0); //wait for the child process to finish
	}
*/	


 /*fork another child process for a1-ece650.py*/
	pid_a1 = fork(); 
	int fds_23[2];//creat the second pipe between a1-ece650.py and a2-ece650
	pid_t pid_a2; //process indicator for a2
	pipe (fds_23);  
		
	if (pid_a1 == (pid_t) 0) {
// 		close (fds_12[0]);

//		dup2 (fds_12[1],STDIN_FILENO); //from this point on, a1 input is connect to the write end of fds_12
//		close (fds_23[1]);
//		dup2 (fds_23[0],STDOUT_FILENO); //connect read end of the second pipe to standard output, so that a2 can read from pipe 23		
		execvp ("python a1-ece650.py",argv); //replace the child process with the python program.
	}
/*	else{
		waitpid (pid_a1,NULL,0); //wait for the child process to finish
	}*/
	
	pid_a2 = fork(); 
	if (pid_a2 == (pid_t) 0) {
 		close (fds_12[0]);
//		dup2 (fds_23[1],STDIN_FILENO);
		execvp ("./a2-ece650",argv); //replace the child process with the "sort" program.

	}
/*	else{
		waitpid (pid_a2,NULL,0); //wait for the child process to finish
	}
*/	


	
	return 1;
}



