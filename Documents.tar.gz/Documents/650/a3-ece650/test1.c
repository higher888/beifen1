/*determine whether new created edge coincide the previous generated*/
int coincide(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4){
	int d;
	double x0,y0;
	d = (y2-y1)*(x4-x3)-(y4-y3)*(x2-x1);
	x0 = ((x2-x1)*(x4-x3)*(y3-y1)+(y2-y1)*(x4-x3)*x1-(y4-y3)*(x2-x1)*x3)/d;
	y0 = ((y2-y1)*(y4-y3)*(x3-x1)+(x2-x1)*(y4-y3)*y1-(x4-x3)*(y2-y1)*y3)/(-d);
	//determine whether the intersection is on the edges
	if ((x0-x1)*(x0-x2)<=0 && (x0-x3)*(x0-x4)<=0 && (y0-y1)*(y0-y2)<=0 && (y0-y3)*(y0-y4)<=0 && d==0)
		return 0;
	else
		return 1;
}

int edgeCheck(int m, int coordinate[m+2],int edge_num,int s_i,int s_j){ 
/*determine if the two nodes are the same*/
	int i,j,c_return,c_return1,temp;

/*determine if the edge are coincide to the other*/
	for(i=0;i<s_i-1;i++){
		for(j=0;j<edge_num+1;j++){
			temp = i * (edge_num +1) + j;
			c_return = coincide(coordinate[temp],coordinate[temp+1],coordinate[temp+2],coordinate[temp+3],coordinate[m-2],coordinate[m-1],coordinate[m],coordinate[m+1]);
		if(c_return==0){
			return 0;
			}
		}
	}	
	for (j=0;j<s_j;j++){
		temp = (s_i-1)*(edge_num+1)+j;
		c_return = coincide(coordinate[temp],coordinate[temp+1],coordinate[temp+2],coordinate[temp+3],coordinate[m-2],coordinate[m-1],coordinate[m],coordinate[m+1]);
		if(c_return==0){
			return 0;
			}
	}
	return 1;
}

main(){
	int coordinate[] = {2,3,3,4,5,6,7,8}
	edgeCheck (6,coordinate,0,1,7


}
