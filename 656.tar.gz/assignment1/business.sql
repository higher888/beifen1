USE yelp_challenge;
CREATE TABLE business(
	business_id VARCHAR(30) NOT NULL PRIMARY KEY,
	full_address VARCHAR(50),
	hours_Mon_open TIME,
	hours_Mon_close TIME,
	hours_Tue_open TIME,
	hours_Tue_close TIME,	
	hours_Wed_open TIME,
	hours_Wed_close TIME,
	hours_Th_open TIME,
	hours_Th_close TIME,
	hours_Fr_open TIME,
	hours_Fr_close TIME,	
	hours_Sa_open TIME,
	hours_Sa_close TIME,
	hours_Sun_open TIME,
	hours_Sun_close TIME,
	open ENUM('True', 'False'),
	city VARCHAR(20),
	review_count INT(10) UNSIGNED,
	name VARCHAR(30),
	longitude FLOAT,
	state VARCHAR(10),
	stars FLOAT UNSIGNED,	
	latitude FLOAT
);
	

CREATE TABLE categories(
	business_id VARCHAR(30) NOT NULL PRIMARY KEY,
	category VARCHAR(30)
);


CREATE TABLE attributies(
	business_id VARCHAR(30) NOT NULL PRIMARY KEY,
	attribute_name VARCHAR(30),
	attribute_value VARCHAR(30)
);	

CREATE TABLE neighborhoods(
	business_id VARCHAR(30) NOT NULL PRIMARY KEY,
	neighbour_name VARCHAR(30)
);

DESC
	
 

